/* Pentomino   */
/* ini.c       */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "pentomino.h"
#include "data.h"
#include "ini.h"


/* local function declarations */

static void          add_line    (struct tnode *, char *, char *, int);   
static struct pnode *rotate      (struct pnode *);
static int           form_exists (struct pnode *, struct pnode *);


/**************************************/
/* read the inifile                   */
/**************************************/

struct tnode *read_pieces(char *inifile)
{
   const int piece_id_len = strlen(PIECE_ID); 

   char         fline[MAXLINE];
   char         *tname = NULL;
   int          tnum = 0;
   struct tnode *curr_piece  = NULL;
   struct tnode *first_piece = NULL;
   FILE         *fp;
   struct stat  stbuf;
   
   int line_ctr=0;

   if ((fp = fopen(inifile, "r")) == NULL ||
       fstat(fileno(fp), &stbuf)  == -1     )
   {
      fprintf(stderr, "%s: %s: ", prg.progname, inifile);
      perror(NULL);
      exit(1);
   }
   if (S_ISDIR(stbuf.st_mode))
   {
      fprintf(stderr, "%s: %s is a directory\n", prg.progname, inifile);
      exit(1);
   }
   
   while ((fgets(fline, MAXLINE, fp)) != NULL)
   {
      line_ctr++;
	 
      if (strlen(fline) >= piece_id_len &&
          0 == strncmp(fline, PIECE_ID, piece_id_len))
      {
         if (curr_piece != NULL)
         {
            if (curr_piece->pos_list == NULL)
            {
               fprintf(stderr, "%s, line %d: Next identifier before definition "
                       "of piece %s (No. %d)\n", inifile, line_ctr,
                       curr_piece->name, curr_piece->number);
               exit(1);
            }

            if (prg.verbose)
            {
               fprintf(stdout, "Read piece %s:\n", curr_piece->name);
               f_print(curr_piece->pos_list->field);
            }
         }
         tname = fline + piece_id_len;
         tname[strlen(tname)-1] = '\0'; 
         tnum++;
	    
         curr_piece = t_alloc(tname, tnum);
         t_add(&first_piece, curr_piece);
      } /* if (strlen(fline) >= ...)) */
	 
      else if (curr_piece != NULL        &&
               (fline[0] == LINE_ID_0 ||
                fline[0] == LINE_ID_1   )  )
      {
         add_line(curr_piece, fline, inifile, line_ctr);
      }
   } /* while ((fline = fgets...)) */
   
   if (curr_piece == NULL)
   {
      fprintf(stderr, "%s, line %d: EOF before any piece definition\n",
              inifile, line_ctr);
      exit(1);
   }
   
   if (curr_piece != NULL && curr_piece->pos_list == NULL)
   {
      fprintf(stderr, "%s, line %d: EOF before definition of "
              "piece %s (No. %d)\n", inifile, line_ctr,
              curr_piece->name, curr_piece->number);
      exit(1);
   }

   if (prg.verbose)
   {
      fprintf(stdout, "Read piece %s:\n", curr_piece->name);
      f_print(curr_piece->pos_list->field);
   }
   fclose(fp);
   
   return first_piece;
}



/***************************************************/
/* add a new line to the first position of a piece */
/***************************************************/

static void add_line(struct tnode *curr_piece,
		     char *fline,
		     char *inifile,
		     int line_ctr)
{
   static struct tnode *same_piece=NULL;
   static int y_ctr=0;

   int i;
   int invalid_char=0;

   if (curr_piece == NULL)
   {
      fprintf(stderr, "%s, line %d: Pointer to piece in add_line() is NULL",
	      inifile, line_ctr);
      exit(1);
   }
   
   if (curr_piece != same_piece)
   {
      same_piece = curr_piece;
      y_ctr = 0;
      t_add_pos(&curr_piece, p_alloc());
   }
   
   if (++y_ctr > YDIM)
   {
      fprintf(stderr, "%s, line %d: Too many definition lines for "
	      "piece %s (No. %d)\n", inifile, line_ctr,
	      curr_piece->name, curr_piece->number);
      exit(1);
   }

   for (i=0; i < XDIM; i++)
   {
      if (fline[i] == LINE_ID_1)
      {
         f_setxy(&curr_piece->pos_list->field, i, y_ctr-1);
         curr_piece->one_count++;
      }
      else if (fline[i] != LINE_ID_0)
      {
         invalid_char = TRUE;
         break;   /* break at the first invalid character */
      }
   }
   if (!invalid_char && (fline[XDIM] == LINE_ID_0 || fline[XDIM] == LINE_ID_1))
   {
      fprintf(stderr, "%s, line %d: Too long definition line for "
              "piece %s (No. %d)\n", inifile, line_ctr,
              curr_piece->name, curr_piece->number);
      exit(1);
   }
}



/********************************************/
/* create the position lists for all pieces */
/********************************************/

void create_pos_lists(struct tnode *first_piece)
{
   struct tnode *curr_piece = NULL;
   struct pnode *rot_list   = NULL;
   struct pnode *curr_rot   = NULL;
   struct pnode *currx_pos  = NULL;
   struct pnode *curry_pos  = NULL;
   struct pnode *tmpx_pos   = NULL;
   struct pnode *tmpy_pos   = NULL;
   
   /* Ueber alle Teilchen ... */   
   for (curr_piece = first_piece;
	curr_piece != NULL;
	curr_piece = curr_piece->next)
   {
      /* Schiebe die allererste Position (aus inifile) in die linke obere Ecke */
      p_shift_lu(curr_piece->pos_list);
      
      /* Erstell die Liste aller Drehungen und Spiegelungen */
      rot_list = rotate(curr_piece->pos_list);

      /* Ueber alle Drehungen und Spiegelungen ... */
      for (curr_rot = rot_list; curr_rot != NULL; curr_rot = curr_rot->next)
      {
	 /* Schiebe die Position auf dem ganzen Feld herum ...*/
	 currx_pos  = p_identity(curr_rot);
	 while (currx_pos != NULL)
	 {
	    tmpx_pos   = currx_pos;
	    currx_pos  = p_right(tmpx_pos);

	    curry_pos  = p_identity(tmpx_pos);
	    while (curry_pos != NULL)
	    {
	       tmpy_pos   = curry_pos;
	       curry_pos  = p_down(tmpy_pos);
	       
	       /* Uebernimm die Position in die Liste falls der Check OK ist */
	       /* und die Position nicht die allererste ist                  */
	       if ( f_plausible(tmpy_pos->field, NULL)      &&
		   !f_cmp(tmpy_pos->field, rot_list->field)   )
	       {
		  t_add_pos(&curr_piece, tmpy_pos);
	       }
	       else
	       {
		  p_free(&tmpy_pos);
	       }
	    }

	    p_free(&tmpx_pos);
	    
	 }
      }   /* for (curr_rot = ... ) */

      p_flush(&rot_list);
      
   }   /* for (curr_piece = ... ) */
}



/*************************************************************/
/* rotate and mirror a position, return ptr to complete list */
/*************************************************************/

static struct pnode *rotate(struct pnode *first_pos)
{
   struct pnode *first_rot    = NULL;
   struct pnode *mirrored_pos = NULL; 
   struct pnode *turned_pos   = NULL;
   int i,j;

/* Use each rotation once per mirage. All these functions */   
/* allocate memory for new positions.                     */
   
   for (i=0; *p_mirror_fct[i] != NULL; i++)
   {
      mirrored_pos = (*p_mirror_fct[i])(first_pos);

      for (j=0; *p_turn_fct[j] != NULL; j++)
      {
	 turned_pos = (*p_turn_fct[j])(mirrored_pos);

	 if (turned_pos != NULL)
	 {
	    if (form_exists(turned_pos, first_rot))
	    {
	       p_free(&turned_pos);
	    }
	    else
	    {
	       p_add(&first_rot, turned_pos);
	    }
	 }
      }
      
      p_free(&mirrored_pos);

   }
   
   return first_rot;
}



/*****************************************************************/
/* check if pos exists in the list plist, return TRUE if it does */ 
/*****************************************************************/

static int form_exists(struct pnode *pos, struct pnode *plist)
{
   struct pnode *curr_pos = NULL;
   int equal = FALSE;
   
   for (curr_pos = plist;
	curr_pos != NULL && !(equal = f_cmp(curr_pos->field, pos->field));
	curr_pos = curr_pos->next);
	
   return equal;
}


/******************************************************************/
/* sort the pieces list by LINE_ID_1s and the number of positions */ 
/******************************************************************/

struct tnode *sort_pieces(struct tnode *first_piece)
{
   struct tnode *base;  /* pointer to the basetable */
   struct tnode *curr_piece;
   struct tnode *next_piece;
   int i;
   
   /* allocate the temporary basetable of pieces */

   if ((base = (struct tnode *)malloc((size_t)(gme.piece_count *
                                     sizeof(struct tnode)))) == NULL)
   {
      fprintf(stderr, "%s: Can't allocate memory for sort-basetable\n", prg.progname);
      exit(1);
   }

   /* initialise the table with our pieces */

   curr_piece = first_piece;   
   for (i=0; i<gme.piece_count; i++)
   {
      if (curr_piece)
      {
         memcpy(&base[i], curr_piece, sizeof(struct tnode));
         curr_piece = curr_piece->next;
      }
      else
      {
         fprintf(stderr, "%s: Piece list is shorter than computed\n", prg.progname);
         exit(1);
      }
   }
   if (curr_piece != NULL)
   {
      fprintf(stderr, "%s: Piece list is longer than computed\n", prg.progname);
      exit(1);
   }

   /* sort the basetable, comparing ones and positions */
   
   qsort((void *)base,
         (size_t)gme.piece_count,
         sizeof(struct tnode),
         t_cmp);

   /* free the original piece list */

   curr_piece = first_piece;
   while (curr_piece != NULL)
   {
      next_piece = curr_piece->next;

      free(curr_piece);

      curr_piece = next_piece;
   }
   
   /* adjust the pointers according to the sorted basetable */

   first_piece = base;
   
   for (i=0; i<gme.piece_count-1; i++)
   {
      base[i].next = &base[i+1]; 
   }
   base[i].next = NULL;

   return first_piece;
}


/*************************************************************/
/* restrict the position list(s) to omit symmetric solutions */
/*************************************************************/

void restrict_pos_lists(struct tnode *first_piece)
{
   /* Ist noch ueberhaupt nicht allgemein gehalten */

   int i,j;
   int free_it;
   struct tnode *piece;
   struct pnode **pos;

   piece = first_piece;      /* This must be piece 'Kreuz' */

   /* Loesche alle Positionen des Teilchens 'Kreuz' wo der */
   /* Schwerpunkt des Teilchens ausserhalb des oberen      */
   /* linken Viertel des Feldes liegt.                     */
   
   pos = &piece->pos_list;

   while (*pos != NULL) 
   {
      free_it = FALSE;
      
      for (i=4; i<YDIM && !free_it; i++)
      {     
	 for (j=0; j<XDIM && !free_it; j++)
	 {
	    if (f_testxy((*pos)->field, j, i))
	    {
	       free_it = TRUE;
	    }
	 }
      }
      for (i=0; i<4 && !free_it; i++)
      {     
	 for (j=6; j<XDIM && !free_it; j++)
	 {
	    if (f_testxy((*pos)->field, j, i))
	    {
	       free_it = TRUE;
	    }
	 }
      }
      
      if (free_it)
      {
	 p_free(pos);
      }
      else
      {
	 pos = &(*pos)->next;
      }
   }
}




